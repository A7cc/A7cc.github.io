/* tunnel_driver.h
 * Created April/2015
 * By Ron Bowes
 *
 * See LICENSE.md
 *
 * This is currently only used for constants. It may be used more in the future,
 * the same way that driver.h is.
 */

typedef enum
{
  TUNNEL_DRIVER_DNS,
} tunnel_driver_type_t;
